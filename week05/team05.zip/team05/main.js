import {showHikeList} from './hikes.js';
window.addEventListener("load", () => {
  //on load grab the array and insert it into the page
  showHikeList();
});

